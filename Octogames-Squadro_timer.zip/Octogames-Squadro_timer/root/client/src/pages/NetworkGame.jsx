import React from 'react'

const NetworkGame = () => {
  return (
    <div>
      
    </div>
  )
}

export default NetworkGame
