import React from 'react'

const BotGame = () => {
  return (
    <div>
      
    </div>
  )
}

export default BotGame
