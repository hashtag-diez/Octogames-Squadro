import React from 'react'

export const AboutUs = () => {
    return (
        <>

            <div id="games">
                <text> Created by the company Octogames  ©<br/>
                        Zeid<br/>
                        Sarah<br/>
                        Maelys<br/>
                        Sophia<br/>
                        Siyani<br/>

                        L3 DANT-Sorbonne Université 2021
                </text>
            </div>

        </>

    )
}
export default AboutUs