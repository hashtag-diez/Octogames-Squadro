import React, { useEffect, useState } from 'react'


export default function WelcomeScreen({ player, setPlayer, socket ,room, setRoom,color,setColor }) {
    const [name, setName] = useState(player.name);
    const [error, setError] = useState();
    const [roomText, setRoomText] = useState("");
    const [createRoom, setCreateRoom] = useState(false);
    const [joinRoom, setJoinRoom] = useState(false);

    //set le nom d'utilisateur
    const handleFormUsername = (e) => {
        e.preventDefault();
        setPlayer({ ...player,  name: name})
    }

    //Envois l'IDRoom au serveur et gère les erreurs
    const handleFormID = (e) => {
        setError("")
        e.preventDefault();

        socket.emit("tryToJoin", roomText);
        socket.on("resultJoiningRoom", (data)=>{
            console.log("Je veux rentrer dans la salle "+roomText)
            if(!data.status){
                setError(data.text)
                console.log("Non je n'ai pas le droit "+data.text)
            }else{
                setRoom(roomText)
                console.log("Oui j'ai le droit "+room)
            }
        })
    }

    // communique avec le serveur pour créer une room et y ajouter le joueur
    useEffect(() => {
        if(createRoom){
            socket.emit("getRoomId");
            console.log("On envoie une demande de creation de salle");
            socket.on("sendRoomId", (data)=>{
                console.log("On recupere le nom de la salle "+data)
                setRoom(data)
            })
        }
    }, [createRoom])

    return (
        <div className="info-pannel">
            <h2 style={{letterSpacing : "1px", padding: "8px 0px"}}>Bienvenue !</h2>
            <hr />
            {player.name ?
                //Nom d'utilisateur renseigné + option "créer une partie" choisi
                createRoom ?
                    (
                        <div className="create-room">
                            Code d'accès :
                            <br/>
                            {room}
                            <br/>
                            <span> Partages ce code avec tes amis ! </span>
                            <br/>
                            <span> En attente de joueur..</span>
                            <button onClick={()=>{socket.emit("exitRoom"); setRoom(); setJoinRoom(false); setCreateRoom(false)}}>Exit</button>
                        </div>
                    ):
                    joinRoom ?
                        //Nom d'utilisateur renseigné + option "rejoindre une partie" choisi
                        (
                            <form className="join-room" onSubmit={handleFormID}>
                                Entrez le code :
                                <br />
                                <input type="text" name="id" id="id" autoComplete="off"
                                       autoFocus="true"
                                       value={roomText} onChange={(e)=>setRoomText(e.target.value)}/>
                                <br/>
                                <i style={{color :"#dd3300", fontSize: "15px"}}>{error}</i>
                                <br />
                                <button type="submit" onClick={setColor('red')}>Rejoindre</button>

                                <button onClick={()=>{setRoom(); setJoinRoom(false); setCreateRoom(false); setRoomText(); setError("")}}>Retour</button>
                            </form>
                        ):

                        // Cas ou seul le pseudo est renseigné
                        (<div className="join-create-menu">
                            Choisis ton mode de jeu :
                            <br />
                            <button onClick={() => {setCreateRoom(true);handleFormID()}}>Crée ta partie !</button>
                            <button onClick={() => {setJoinRoom(true);socket.join(room)}}>Rejoins un ami !</button>
                        </div>)
                :
                // Pas encore de nom d'utilisateur, demandez de rentrer un pseudo avant de continuer
                <form className="players-name" onSubmit={handleFormUsername} >
                    Enter Your name
                    <br />
                    <input type="text" name="name" id="name" autoComplete="off" autoFocus="true"
                           value={name} onChange={(e)=>setName(e.target.value)}/>
                    <br />
                    <button type="submit">Submit</button>
                </form>
            }
        </div>
    )
}